package cs1302.utility;

public class MyMethods{
    public static int greater(int a, int b){
	return (a > b) ? a : b;
    }
}
